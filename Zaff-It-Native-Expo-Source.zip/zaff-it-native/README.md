# Zaff-It Native (Expo / React Native)

Android-first native app starter for Zaff-It. This is a React Native app, not a website wrapper.

## Run
1. Install Node.js 20.19.4+ on a computer.
2. Extract this project and run `npm install`.
3. Run `npx expo start` and open it with Expo Go, or use `npx expo run:android` with Android Studio installed.
4. For a distributable APK/AAB, configure EAS Build and run `eas build -p android`.

## Current scope
- Native customer UI with Home, Explore, Basket, Orders and Zaff tabs
- Sample catalogue, search, category filter and basket quantity controls
- Demo checkout and local in-memory order history
- Makrana pilot placeholder and Zaff module launcher

## Not connected yet
No backend/database, login/OTP, live stock, merchant/rider/admin consoles, real payments, maps, push notifications or production order tracking. Product data is sample data. Demo checkout does not collect money.
